package pandha.swe.localsharing.model.dao;

import pandha.swe.localsharing.model.Hilfeleistung;

public interface HilfeleistungDAO extends AngebotsDAO<Hilfeleistung> {



}
