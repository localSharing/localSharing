package pandha.swe.localsharing.controller.angebot.backend;

public interface IstAnfrageErlaubt {

	public Boolean istAnfrageErlaubt();

}
