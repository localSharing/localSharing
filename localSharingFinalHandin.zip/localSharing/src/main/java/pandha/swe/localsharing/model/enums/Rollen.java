package pandha.swe.localsharing.model.enums;

public enum Rollen {

	USER, ADMIN
}
