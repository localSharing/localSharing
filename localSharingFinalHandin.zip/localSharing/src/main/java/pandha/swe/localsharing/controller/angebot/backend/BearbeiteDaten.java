package pandha.swe.localsharing.controller.angebot.backend;

import java.util.Map;

public abstract class BearbeiteDaten {

	public abstract void bearbeite(Map<String, Object> ladeDaten);

}
