package pandha.swe.localsharing.model.enums;

public enum AnfrageStatus {
	
	angenommen, abgelehnt, offen, gesperrt;

}
