package pandha.swe.localsharing.service;

import pandha.swe.localsharing.model.Ausleihartikel;
import pandha.swe.localsharing.model.dto.AusleihartikelDTO;

public interface AusleihartikelService extends
		LS_AngebotService<Ausleihartikel, AusleihartikelDTO> {

}
