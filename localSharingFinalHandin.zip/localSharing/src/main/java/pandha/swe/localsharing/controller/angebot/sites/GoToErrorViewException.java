package pandha.swe.localsharing.controller.angebot.sites;

public class GoToErrorViewException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
