package pandha.swe.localsharing.model.enums;

public enum FileUploadType {
	USER, AUSLEIHANGEBOT, TAUSCHANGEBOT, HILFANGEBOT, DEFAULT_USER, DEFAULT_ANGEBOT
}
