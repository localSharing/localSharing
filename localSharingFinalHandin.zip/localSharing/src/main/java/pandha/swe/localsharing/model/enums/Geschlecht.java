package pandha.swe.localsharing.model.enums;

public enum Geschlecht {
	MANN, FRAU
}
