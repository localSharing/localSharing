package pandha.swe.localsharing.model.enums;

public enum Kontaktart {

	telefon, email;

}
