package pandha.swe.localsharing.controller.angebot.backend.holedaten;

import java.util.Map;

public abstract class LadeDaten {

	public LadeDaten() {
		super();
	}

	public abstract Map<String, Object> ladeDaten();

}