package pandha.swe.localsharing.service;

import pandha.swe.localsharing.model.Tauschartikel;
import pandha.swe.localsharing.model.dto.TauschartikelDTO;

public interface TauschartikelService extends
		LS_AngebotService<Tauschartikel, TauschartikelDTO> {

}
