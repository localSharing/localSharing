package pandha.swe.localsharing.model.dao;

import pandha.swe.localsharing.model.Ausleihartikel;

public interface AusleihartikelDAO extends AngebotsDAO<Ausleihartikel> {

}
