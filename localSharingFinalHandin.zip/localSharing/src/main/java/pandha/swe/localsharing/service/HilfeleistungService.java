package pandha.swe.localsharing.service;

import pandha.swe.localsharing.model.Hilfeleistung;
import pandha.swe.localsharing.model.dto.HilfeleistungDTO;

public interface HilfeleistungService extends
		LS_AngebotService<Hilfeleistung, HilfeleistungDTO> {

}
