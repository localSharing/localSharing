package pandha.swe.localsharing;

public class StringConstants {

	public static final String AUSLEIHEN = "ausleihen";
	public static final String TAUSCHEN = "tauschen";
	public static final String HELFEN = "helfen";

}
